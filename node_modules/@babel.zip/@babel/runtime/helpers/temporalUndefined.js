function _temporalUndefined() {}

module.exports = _temporalUndefined;
module.exports["default"] = module.exports, module.exports.__esModule = true;